# YouTube Feeds Example for Feathers

A simple application that uses the [YouTube Data API](https://developers.google.com/youtube/2.0/reference) to display feeds using [Feathers](http://feathersui.com/) components.

## Web Demo

View the [YouTube Feeds example](http://feathersui.com/examples/youtube-feeds/) in your browser.