# Feathers Components Explorer

A little bit of everything in [Feathers](http://feathersui.com/), presented as a mobile app. Includes screens for each component, with configurable options.

## Web Demo

View the [Components Explorer](http://feathersui.com/examples/components-explorer/) in your browser.