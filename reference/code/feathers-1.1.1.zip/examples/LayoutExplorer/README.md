# Layout Explorer for Feathers

Demonstrations of each layout available in [Feathers](http://feathersui.com/) for the List and LayoutContainer components, presented as a mobile app. Includes screens for each layout, with configurable options.

## Web Demo

View the [Layout Explorer Example](http://feathersui.com/examples/layout-explorer/) in your browser.