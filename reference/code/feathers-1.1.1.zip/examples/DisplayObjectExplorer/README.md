# Display Object Explorer for Feathers

Demonstrates the resizing behavior of `Scale9Image`, `Scale3Image`, and `TiledImage` display objects from [Feathers](http://feathersui.com/).

## Web Demo

View the [Display Object Explorer](http://feathersui.com/examples/display-object-explorer/) in your browser.