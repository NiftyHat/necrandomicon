# Hello World Example for Feathers

A very simple example that creates a Button control from the [Feathers](http://feathersui.com/) library, presented as a mobile app.

## Web Demo

View the [Hello World Example](http://feathersui.com/examples/hello-world/) in your browser.